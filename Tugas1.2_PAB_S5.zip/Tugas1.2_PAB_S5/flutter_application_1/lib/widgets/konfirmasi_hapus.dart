import 'package:flutter/material.dart';

import '../models/tugas.dart';

/// Menampilkan dialog konfirmasi. Mengembalikan true jika pengguna memilih Hapus.
Future<bool> konfirmasiHapus(BuildContext context, Tugas tugas) async {
  final hasil = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: const Text('Hapus tugas?'),
      content: Text('Tugas "${tugas.judul}" akan dihapus.'),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(dialogContext, false),
          child: const Text('Batal'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(dialogContext, true),
          child: const Text('Hapus'),
        ),
      ],
    ),
  );
  return hasil ?? false;
}
