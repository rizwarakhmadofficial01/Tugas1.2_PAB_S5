class AppRoutes {
  static const home = '/';
  static const tambah = '/tambah';
  static const edit = '/edit';
}
