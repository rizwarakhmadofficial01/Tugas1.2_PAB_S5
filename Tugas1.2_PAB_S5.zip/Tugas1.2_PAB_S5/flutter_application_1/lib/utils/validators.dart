class Validators {
  static String? wajib(String? v, {String field = 'Field'}) {
    if (v == null || v.trim().isEmpty) return '$field wajib diisi';
    return null;
  }

  static String? minPanjang(String? v, int min, {String field = 'Field'}) {
    if (v == null || v.trim().length < min) {
      return '$field minimal $min karakter';
    }
    return null;
  }

  static String? maksPanjang(String? v, int max, {String field = 'Field'}) {
    if (v != null && v.length > max) {
      return '$field maksimal $max karakter';
    }
    return null;
  }
}
