import 'package:flutter/foundation.dart';

import '../models/tugas.dart';

class TugasViewModel extends ChangeNotifier {
  final List<Tugas> _daftar = [];

  List<Tugas> get proses => _daftar.where((t) => !t.selesai).toList();
  List<Tugas> get selesai => _daftar.where((t) => t.selesai).toList();
  List<Tugas> get terlambat => _daftar.where((t) => t.terlambat).toList();
  int get total => _daftar.length;

  void tambah(Tugas tugas) {
    _daftar.add(tugas);
    notifyListeners();
  }

  void perbarui(Tugas lama, Tugas baru) {
    final index = _daftar.indexOf(lama);
    if (index == -1) return;
    _daftar[index] = baru;
    notifyListeners();
  }

  void toggleSelesai(Tugas tugas) {
    tugas.selesai = !tugas.selesai;
    notifyListeners();
  }

  void hapus(Tugas tugas) {
    _daftar.remove(tugas);
    notifyListeners();
  }
}
