import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'pages/main_page.dart';
import 'pages/tambah_tugas_page.dart';
import 'routes.dart';
import 'viewmodels/tugas_viewmodel.dart';

void main() {
  runApp(
    // State bersama (Provider): satu TugasViewModel untuk seluruh aplikasi
    ChangeNotifierProvider(
      create: (_) => TugasViewModel(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TugasKu',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
      initialRoute: AppRoutes.home,
      // Named routes: halaman form dipakai untuk tambah (/tambah) dan edit (/edit)
      routes: {
        AppRoutes.home: (_) => const MainPage(),
        AppRoutes.tambah: (_) => const TambahTugasPage(),
        AppRoutes.edit: (_) => const TambahTugasPage(),
      },
    );
  }
}
