class Tugas {
  final String judul;
  final String matkul;
  final DateTime deadline;
  final String catatan;
  bool selesai;

  Tugas({
    required this.judul,
    required this.matkul,
    required this.deadline,
    this.catatan = '',
    this.selesai = false,
  });

  /// Format tanggal dd/mm/yyyy
  static String formatTanggal(DateTime d) {
    String dua(int n) => n.toString().padLeft(2, '0');
    return '${dua(d.day)}/${dua(d.month)}/${d.year}';
  }

  String get deadlineTeks => formatTanggal(deadline);

  /// Terlambat: belum selesai dan deadline sebelum hari ini
  bool get terlambat {
    if (selesai) return false;
    final now = DateTime.now();
    final hariIni = DateTime(now.year, now.month, now.day);
    return deadline.isBefore(hariIni);
  }
}
