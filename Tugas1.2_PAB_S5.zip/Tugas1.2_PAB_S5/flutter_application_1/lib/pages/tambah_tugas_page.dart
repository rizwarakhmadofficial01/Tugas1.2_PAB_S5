import 'package:flutter/material.dart';

import '../models/tugas.dart';
import '../utils/validators.dart';

/// Form untuk menambah tugas (/tambah) dan mengedit tugas (/edit).
/// Jika ada arguments bertipe Tugas, form berada dalam mode edit.
class TambahTugasPage extends StatefulWidget {
  const TambahTugasPage({super.key});

  @override
  State<TambahTugasPage> createState() => _TambahTugasPageState();
}

class _TambahTugasPageState extends State<TambahTugasPage> {
  final _formKey = GlobalKey<FormState>();
  final _judulCtrl = TextEditingController();
  final _tanggalCtrl = TextEditingController();
  final _catatanCtrl = TextEditingController();

  String? _matkul;
  DateTime? _deadline;
  Tugas? _lama; // tidak null jika mode edit
  bool _siap = false;

  static const _daftarMatkul = [
    'Pemrograman Aplikasi Bergerak',
    'Basis Data',
    'Jaringan Komputer',
    'Keamanan Sistem',
  ];

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_siap) return;
    _siap = true;

    // Terima data dari named route (arguments)
    final arg = ModalRoute.of(context)?.settings.arguments;
    if (arg is Tugas) {
      _lama = arg;
      _judulCtrl.text = arg.judul;
      _catatanCtrl.text = arg.catatan;
      _matkul = arg.matkul;
      _deadline = arg.deadline;
      _tanggalCtrl.text = arg.deadlineTeks;
    }
  }

  @override
  void dispose() {
    _judulCtrl.dispose();
    _tanggalCtrl.dispose();
    _catatanCtrl.dispose();
    super.dispose();
  }

  Future<void> _pilihTanggal() async {
    final hariIni = DateUtils.dateOnly(DateTime.now());
    final hasil = await showDatePicker(
      context: context,
      initialDate: _deadline ?? hariIni,
      firstDate: DateTime(hariIni.year - 1),
      lastDate: DateTime(hariIni.year + 2),
    );
    if (hasil != null) {
      setState(() {
        _deadline = hasil;
        _tanggalCtrl.text = Tugas.formatTanggal(hasil);
      });
    }
  }

  void _simpan() {
    if (!_formKey.currentState!.validate()) return; // berhenti jika tidak valid

    final hasil = Tugas(
      judul: _judulCtrl.text.trim(),
      matkul: _matkul!,
      deadline: _deadline!,
      catatan: _catatanCtrl.text.trim(),
      selesai: _lama?.selesai ?? false,
    );
    Navigator.pop(context, hasil); // kembalikan data lewat pop
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_lama == null ? 'Tambah Tugas' : 'Edit Tugas'),
      ),
      body: Form(
        key: _formKey,
        autovalidateMode: AutovalidateMode.onUserInteraction,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _judulCtrl,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                labelText: 'Judul tugas',
                prefixIcon: Icon(Icons.title),
                border: OutlineInputBorder(),
              ),
              validator: (v) {
                final wajib = Validators.wajib(v, field: 'Judul');
                if (wajib != null) return wajib;
                return Validators.minPanjang(v, 3, field: 'Judul');
              },
            ),
            const SizedBox(height: 16),
            FormField<String>(
              initialValue: _matkul,
              validator: (v) => v == null ? 'Pilih mata kuliah' : null,
              builder: (field) => InputDecorator(
                isEmpty: field.value == null,
                decoration: InputDecoration(
                  labelText: 'Mata kuliah',
                  prefixIcon: const Icon(Icons.menu_book_outlined),
                  border: const OutlineInputBorder(),
                  errorText: field.errorText,
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: field.value,
                    isExpanded: true,
                    isDense: true,
                    items: [
                      for (final m in _daftarMatkul)
                        DropdownMenuItem<String>(value: m, child: Text(m)),
                    ],
                    onChanged: (v) {
                      field.didChange(v);
                      setState(() => _matkul = v);
                    },
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _tanggalCtrl,
              readOnly: true, // diisi lewat date picker, bukan keyboard
              onTap: _pilihTanggal,
              decoration: const InputDecoration(
                labelText: 'Deadline',
                prefixIcon: Icon(Icons.event),
                suffixIcon: Icon(Icons.calendar_today),
                border: OutlineInputBorder(),
              ),
              validator: (_) =>
                  _deadline == null ? 'Pilih tanggal deadline' : null,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _catatanCtrl,
              maxLength: 200,
              maxLines: 3,
              keyboardType: TextInputType.multiline,
              decoration: const InputDecoration(
                labelText: 'Catatan (opsional)',
                alignLabelWithHint: true,
                prefixIcon: Icon(Icons.notes),
                border: OutlineInputBorder(),
              ),
              validator: (v) =>
                  Validators.maksPanjang(v, 200, field: 'Catatan'),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _simpan,
              icon: const Icon(Icons.save),
              label: const Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }
}
