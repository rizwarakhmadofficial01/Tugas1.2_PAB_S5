import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../viewmodels/tugas_viewmodel.dart';

class ProfilPage extends StatelessWidget {
  const ProfilPage({super.key});

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<TugasViewModel>();

    return Scaffold(
      appBar: AppBar(title: const Text('Profil')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const ListTile(
            leading: CircleAvatar(child: Icon(Icons.person)),
            title: Text('Akhmad Rizwar Afdhal'),
            subtitle: Text('NPM 2410020076 • 5A SI Reguler Banjarbaru'),
          ),
          const ListTile(
            leading: Icon(Icons.school_outlined),
            title: Text('Semester V (Lima)'),
            subtitle: Text('Tahun Angkatan 2024'),
          ),
          const Divider(),
          ListTile(
            title: const Text('Total tugas'),
            trailing: Text('${vm.total}'),
          ),
          ListTile(
            title: const Text('Dalam proses'),
            trailing: Text('${vm.proses.length}'),
          ),
          ListTile(
            title: const Text('Selesai'),
            trailing: Text('${vm.selesai.length}'),
          ),
          ListTile(
            title: const Text('Terlambat'),
            trailing: Text('${vm.terlambat.length}'),
          ),
        ],
      ),
    );
  }
}
