import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/tugas.dart';
import '../routes.dart';
import '../viewmodels/tugas_viewmodel.dart';
import '../widgets/konfirmasi_hapus.dart';

class DetailTugasPage extends StatefulWidget {
  final Tugas tugas; // data diterima lewat constructor

  const DetailTugasPage({super.key, required this.tugas});

  @override
  State<DetailTugasPage> createState() => _DetailTugasPageState();
}

class _DetailTugasPageState extends State<DetailTugasPage> {
  late Tugas _tugas; // state lokal: data yang sedang ditampilkan

  @override
  void initState() {
    super.initState();
    _tugas = widget.tugas;
  }

  String get _status {
    if (_tugas.selesai) return 'Selesai';
    if (_tugas.terlambat) return 'Terlambat';
    return 'Dalam proses';
  }

  // Kirim data lewat arguments, terima data baru lewat pop
  Future<void> _edit() async {
    final hasil = await Navigator.pushNamed(
      context,
      AppRoutes.edit,
      arguments: _tugas,
    );
    if (!mounted) return;
    if (hasil is Tugas) {
      context.read<TugasViewModel>().perbarui(_tugas, hasil);
      setState(() => _tugas = hasil);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Tugas berhasil diperbarui')),
      );
    }
  }

  Future<void> _hapus() async {
    final ya = await konfirmasiHapus(context, _tugas);
    if (!ya || !mounted) return;
    context.read<TugasViewModel>().hapus(_tugas);
    Navigator.pop(context);
  }

  void _toggleSelesai() {
    context.read<TugasViewModel>().toggleSelesai(_tugas);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Detail Tugas')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            _tugas.judul,
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.centerLeft,
            child: Chip(label: Text(_status)),
          ),
          const SizedBox(height: 8),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.menu_book_outlined),
            title: const Text('Mata kuliah'),
            subtitle: Text(_tugas.matkul),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.event),
            title: const Text('Deadline'),
            subtitle: Text(_tugas.deadlineTeks),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.notes),
            title: const Text('Catatan'),
            subtitle: Text(_tugas.catatan.isEmpty ? '-' : _tugas.catatan),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: _toggleSelesai,
            icon: Icon(_tugas.selesai ? Icons.undo : Icons.check),
            label: Text(
              _tugas.selesai ? 'Tandai belum selesai' : 'Tandai selesai',
            ),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _edit,
            icon: const Icon(Icons.edit),
            label: const Text('Edit'),
          ),
          const SizedBox(height: 8),
          TextButton.icon(
            onPressed: _hapus,
            icon: const Icon(Icons.delete_outline),
            label: const Text('Hapus'),
          ),
        ],
      ),
    );
  }
}
