import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/tugas.dart';
import '../routes.dart';
import '../viewmodels/tugas_viewmodel.dart';
import '../widgets/konfirmasi_hapus.dart';
import 'detail_tugas_page.dart';

class DaftarTugasPage extends StatelessWidget {
  const DaftarTugasPage({super.key});

  // Named route + menerima data balik lewat pop
  Future<void> _bukaForm(BuildContext context) async {
    final hasil = await Navigator.pushNamed(context, AppRoutes.tambah);
    if (!context.mounted) return;
    if (hasil is Tugas) {
      context.read<TugasViewModel>().tambah(hasil);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Tugas berhasil ditambahkan')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<TugasViewModel>(); // rebuild saat data berubah

    return DefaultTabController(
      length: 3, // sama dengan jumlah Tab dan isi TabBarView
      child: Scaffold(
        appBar: AppBar(
          title: const Text('TugasKu'),
          bottom: TabBar(
            tabs: [
              Tab(text: 'Proses (${vm.proses.length})'),
              Tab(text: 'Selesai (${vm.selesai.length})'),
              Tab(text: 'Terlambat (${vm.terlambat.length})'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _ListTugas(
              daftar: vm.proses,
              pesanKosong: 'Belum ada tugas yang sedang diproses',
            ),
            _ListTugas(
              daftar: vm.selesai,
              pesanKosong: 'Belum ada tugas yang selesai',
            ),
            _ListTugas(
              daftar: vm.terlambat,
              pesanKosong: 'Tidak ada tugas yang terlambat',
            ),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () => _bukaForm(context),
          tooltip: 'Tambah tugas',
          child: const Icon(Icons.add),
        ),
      ),
    );
  }
}

class _ListTugas extends StatelessWidget {
  final List<Tugas> daftar;
  final String pesanKosong;

  const _ListTugas({required this.daftar, required this.pesanKosong});

  @override
  Widget build(BuildContext context) {
    if (daftar.isEmpty) {
      return Center(child: Text(pesanKosong));
    }
    return ListView.builder(
      itemCount: daftar.length,
      itemBuilder: (context, i) {
        final t = daftar[i];
        return ListTile(
          // Navigator.push biasa, data dikirim lewat constructor
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => DetailTugasPage(tugas: t)),
          ),
          leading: Checkbox(
            value: t.selesai,
            onChanged: (_) => context.read<TugasViewModel>().toggleSelesai(t),
          ),
          title: Text(
            t.judul,
            style: TextStyle(
              decoration: t.selesai ? TextDecoration.lineThrough : null,
            ),
          ),
          subtitle: Text(
            '${t.matkul} • ${t.deadlineTeks}',
            style: TextStyle(
              color: t.terlambat ? Theme.of(context).colorScheme.error : null,
            ),
          ),
          trailing: IconButton(
            icon: const Icon(Icons.delete_outline),
            tooltip: 'Hapus',
            onPressed: () async {
              final ya = await konfirmasiHapus(context, t);
              if (ya && context.mounted) {
                context.read<TugasViewModel>().hapus(t);
              }
            },
          ),
        );
      },
    );
  }
}
